@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
if errorlevel 1 (
 echo No fue posible instalar las dependencias. Verifica Python 3.11+ y tu conexion.
 pause
 exit /b 1
)
echo.
echo Abre http://127.0.0.1:8000 en tu navegador.
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
