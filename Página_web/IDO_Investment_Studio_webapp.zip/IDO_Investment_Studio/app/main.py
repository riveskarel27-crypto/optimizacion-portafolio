"""IDO Investment Studio · FastAPI. Ejecutar: uvicorn app.main:app --reload"""
from __future__ import annotations
from datetime import datetime, timezone, timedelta
from pathlib import Path
import logging
import shutil
from uuid import UUID, uuid4

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .engine import AnalysisError, clean_tickers, resolve_period, load_prices, calculate, serialize, PROFILES, STRATEGIES
from .reporting import export_run

BASE = Path(__file__).resolve().parent.parent
STATIC = BASE / "static"
RUNS = BASE / "runs"
RUNS.mkdir(parents=True, exist_ok=True)
log = logging.getLogger("ido")
app = FastAPI(title="IDO Investment Studio", version="1.0.0", docs_url="/api/docs")
app.mount("/static", StaticFiles(directory=STATIC), name="static")

class AnalysisRequest(BaseModel):
    tickers: list[str] = Field(min_length=2, max_length=12)
    profile: str = "moderado"
    strategy: str = "long"
    auto_period: bool = True
    start_date: str | None = None
    end_date: str | None = None
    risk_free_rate: float = Field(default=4., ge=0, lt=100)
    alpha: float = Field(default=.05, gt=0, lt=1)


def purge_old_runs(hours: int = 24):
    cutoff = datetime.now(timezone.utc).timestamp() - hours*3600
    for p in RUNS.iterdir():
        if p.is_dir() and p.stat().st_mtime < cutoff:
            shutil.rmtree(p, ignore_errors=True)


@app.get("/")
def home():
    return FileResponse(STATIC / "index.html")


@app.get("/api/config")
def config():
    return {"profiles": {k:v["label"] for k,v in PROFILES.items()},
            "strategies": {k:{"label":v["label"], "interval":v["interval"], "days":v["days"],
                              "max_days":v["max_days"]} for k,v in STRATEGIES.items()}}


@app.get("/api/health")
def health():
    return {"status": "ok", "service":"IDO Investment Studio"}


@app.post("/api/analyze")
def analyze(req: AnalysisRequest):
    try:
        tickers = clean_tickers(req.tickers)
        start, end, exclusive, info = resolve_period(req.strategy, req.start_date, req.end_date, req.auto_period)
        prices, warnings = load_prices(tickers, start, exclusive, info["interval"])
        if any(t.endswith(".MX") for t in tickers) and any(not t.endswith(".MX") for t in tickers):
            warnings.append("Hay títulos de distintos mercados/monedas (.MX y otros): el modelo combina retornos porcentuales en monedas de cotización sin cubrir ni convertir el riesgo cambiario; expresa la cartera en una moneda base antes de invertir.")
        result = calculate(prices, profile=req.profile, strategy=req.strategy,
                           rf=req.risk_free_rate / 100, alpha=req.alpha, warnings=warnings)
        result.config.update({"requested_start": start, "requested_end": end, "auto_period":req.auto_period})
        purge_old_runs()
        run_id = str(uuid4())
        run_dir = RUNS/run_id
        try:
            export_run(result, run_dir, run_id)
        except Exception:
            shutil.rmtree(run_dir, ignore_errors=True)
            raise
        return serialize(result, run_id)
    except AnalysisError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        log.exception("No se pudo ejecutar el análisis")
        raise HTTPException(status_code=500, detail="Error al procesar la solicitud; revisa la conexión a Yahoo y el registro del servidor.") from exc


ALLOWED_FILES = {"pdf": "Informe_IDO.pdf", "zip":"IDO_Analisis_Completo.zip",
                 "region":"region_factible.png", "hist":"histogramas.png",
                 "prices":"precios_comparados.png"}

@app.get("/api/download/{run_id}/{kind}")
def download(run_id: str, kind: str):
    try:
        validated = str(UUID(run_id))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="Identificador no encontrado.") from exc
    if kind not in ALLOWED_FILES:
        raise HTTPException(status_code=404, detail="Documento no disponible.")
    path = RUNS/validated/ALLOWED_FILES[kind]
    if not path.is_file():
        raise HTTPException(status_code=404, detail="El informe expiró. Ejecuta un nuevo análisis.")
    # Los identificadores son aleatorios; para despliegue multiusuario se necesita autenticación.
    return FileResponse(path, filename=path.name if kind in ("pdf", "zip") else None,
                        media_type="application/pdf" if kind == "pdf" else
                                   "application/zip" if kind == "zip" else "image/png")
