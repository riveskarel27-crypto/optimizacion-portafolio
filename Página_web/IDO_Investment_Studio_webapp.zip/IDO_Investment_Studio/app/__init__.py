"""IDO Investment Studio application."""
