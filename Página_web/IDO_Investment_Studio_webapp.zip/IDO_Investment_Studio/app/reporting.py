"""Gráficas financieras, CSV, informe PDF y archivo ZIP reproducible."""
from __future__ import annotations
import io
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                Image, KeepTogether, PageBreak, HRFlowable)

from .engine import Result, serialize

CHARCOAL = "#171B22"
GOLD = "#A98C55"
INK = colors.HexColor("#17202C")
LIGHT = colors.HexColor("#F5F6F8")


def theme_ax(ax):
    ax.set_facecolor("white")
    for spine in ax.spines.values(): spine.set_color("#DDDFE4")
    ax.grid(alpha=.16)
    ax.tick_params(colors="#364354")


def make_region_plot(result: Result, path: Path):
    f = result.frontier
    fig, ax = plt.subplots(figsize=(11.5, 7.0), dpi=135)
    fig.patch.set_facecolor("white")
    theme_ax(ax)
    y = f["return"].to_numpy() * 100
    xl = f["min_volatility"].to_numpy() * 100
    xr = f["max_volatility"].to_numpy() * 100
    ax.fill_betweenx(y, xl, xr, alpha=.20, color="#B89C64", label="Región factible")
    efficient = f["efficient"].to_numpy(dtype=bool)
    ax.plot(xl[efficient], y[efficient], color="#987740", lw=2.8, label="Frontera eficiente")
    if (~efficient).any(): ax.plot(xl[~efficient], y[~efficient], "--", color="#8792A1", lw=1.8, label="Rama ineficiente")
    ax.plot(xr, y, color="#9EADBD", lw=1.2, label="Borde de mayor riesgo")
    for t in result.tickers:
        x = 100*np.sqrt(max(0,result.sigma.loc[t,t]))
        yy = 100*result.mu[t]
        ax.scatter([x],[yy], c="#252F3A", s=33, zorder=4)
        ax.annotate(t, (x, yy), xytext=(5,5), textcoords="offset points", fontsize=8, color="#354257")
    markers = [("Perfil recomendado", "D", "#B28F4B", 100), ("Mínima varianza", "*", "#256E74", 180),
               ("Máximo Sharpe", "^", "#8A5563", 95), ("Equiponderado", "o", "#697990", 60)]
    for name, marker, c, size in markers:
        metrics = result.portfolios.loc[result.portfolios["portfolio"]==name].iloc[0]
        ax.scatter([metrics["volatility"]*100],[metrics["return"]*100], c=c, marker=marker,
                   s=size, zorder=6, edgecolors="white", linewidths=.9, label=name)
    tang = result.portfolios.loc[result.portfolios["portfolio"]=="Máximo Sharpe"].iloc[0]
    if tang["sharpe"] is not None and tang["sharpe"] > 0 and result.config["rf"] < result.mu.max():
        xmax = max(xr.max(), result.portfolios["volatility"].max()*100)*1.06
        xx = np.linspace(0, xmax, 80)
        ax.plot(xx, result.config["rf"]*100+float(tang["sharpe"])*xx, "-.",
                color="#4B8069", lw=1.4, label="CAL hipotética")
    ax.set_xlabel("Volatilidad anual estimada (%)", fontsize=10)
    ax.set_ylabel("Rendimiento anual esperado (%)", fontsize=10)
    ax.set_title("Región factible y frontera eficiente", fontsize=17, color="#1D2836", loc="left", pad=17)
    ax.set_xlim(left=0)
    ax.legend(fontsize=8, loc="best", frameon=True)
    fig.tight_layout()
    fig.savefig(path, dpi=160, bbox_inches="tight")
    plt.close(fig)


def make_histograms(result: Result, path: Path):
    count = len(result.tickers)
    cols, rows = 2, int(np.ceil(count/2))
    fig, axes = plt.subplots(rows, cols, figsize=(12, 3.8*rows), squeeze=False)
    fig.patch.set_facecolor("white")
    for i, ticker in enumerate(result.tickers):
        ax = axes.flat[i]
        theme_ax(ax)
        sample = result.returns[ticker]
        ax.hist(sample, bins=min(45, max(12,int(np.sqrt(len(sample)) * 1.8))), density=True,
                alpha=.70, color="#9FAEBF", edgecolor="white", label="Rendimientos")
        sd, mn = float(sample.std(ddof=1)), float(sample.mean())
        if sd > 0:
            xs = np.linspace(float(sample.min()), float(sample.max()), 260)
            ax.plot(xs, stats.norm.pdf(xs, loc=mn, scale=sd), color="#A4854E", lw=2, label="Normal ajustada")
        ax.axvline(mn, linestyle="--", color="#354257", lw=1.2, label="Media")
        ax.set_title(ticker, fontweight="bold", loc="left", color="#253143")
        ax.set_xlabel("Rendimiento simple por barra")
        ax.set_ylabel("Densidad")
        ax.legend(fontsize=7)
    for i in range(count, rows*cols): axes.flat[i].axis("off")
    fig.suptitle("Diagnóstico empírico: distribuciones y ajuste normal", fontsize=16, y=1.01)
    fig.tight_layout()
    fig.savefig(path, dpi=140, bbox_inches="tight")
    plt.close(fig)


def make_prices(result: Result, path: Path):
    fig, ax = plt.subplots(figsize=(11.5, 5.4))
    fig.patch.set_facecolor("white")
    theme_ax(ax)
    normalized = result.prices.div(result.prices.iloc[0]).mul(100)
    for t in result.tickers:
        ax.plot(normalized.index, normalized[t], linewidth=1.7, label=t)
    ax.set_title("Evolución comparada · base 100", loc="left", fontsize=16, pad=16)
    ax.set_ylabel("Precio ajustado normalizado")
    ax.legend(loc="best", ncol=min(4,len(result.tickers)), fontsize=8)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def equation_image(formulas: list[str], path: Path):
    fig, axes = plt.subplots(len(formulas), 1, figsize=(9.3, len(formulas)*.55), dpi=130)
    axes = np.atleast_1d(axes)
    for ax, formula in zip(axes, formulas):
        ax.axis("off")
        ax.text(.03, .48, f"${formula}$", ha="left", va="center", fontsize=14, color="#222B38")
    fig.patch.set_facecolor("white")
    fig.tight_layout(pad=.5)
    fig.savefig(path, dpi=155, bbox_inches="tight")
    plt.close(fig)


def export_run(result: Result, directory: Path, run_id: str):
    directory.mkdir(parents=True, exist_ok=True)
    result.prices.to_csv(directory/"01_precios_ajustados.csv", encoding="utf-8-sig")
    result.returns.to_csv(directory/"02_rendimientos_simples.csv", encoding="utf-8-sig")
    result.stats.to_csv(directory/"03_estadistica_shapiro.csv", index=False, encoding="utf-8-sig")
    result.mu.to_csv(directory/"04_vector_mu_anual.csv", encoding="utf-8-sig")
    result.sigma.to_csv(directory/"05_matriz_covarianza_anual.csv", encoding="utf-8-sig")
    result.correlation.to_csv(directory/"06_matriz_correlacion.csv", encoding="utf-8-sig")
    result.portfolios.to_csv(directory/"07_comparacion_portafolios.csv", index=False, encoding="utf-8-sig")
    result.weights.to_csv(directory/"08_pesos_optimos.csv", encoding="utf-8-sig")
    result.frontier.to_csv(directory/"09_bordes_region_factible.csv", index=False, encoding="utf-8-sig")
    result.rankings.to_csv(directory/"10_ranking_activos.csv", index=False, encoding="utf-8-sig")
    make_region_plot(result, directory/"region_factible.png")
    make_histograms(result, directory/"histogramas.png")
    make_prices(result, directory/"precios_comparados.png")
    with open(directory/"analisis_completo.json", "w", encoding="utf-8") as f:
        json.dump(serialize(result, run_id), f, ensure_ascii=False, indent=2)
    make_pdf(result, directory/"Informe_IDO.pdf")
    with zipfile.ZipFile(directory/"IDO_Analisis_Completo.zip", "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(directory.iterdir()):
            if p.is_file() and p.name != "IDO_Analisis_Completo.zip":
                z.write(p, arcname=p.name)


def make_pdf(result: Result, path: Path):
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="IDOTitle", parent=styles["Title"], fontName="Helvetica-Bold",
                              fontSize=25, leading=29, textColor=INK, spaceAfter=10))
    styles.add(ParagraphStyle(name="IDOH1", parent=styles["Heading1"], fontSize=13, leading=18,
                              textColor=INK, spaceBefore=18, spaceAfter=7))
    styles.add(ParagraphStyle(name="IDOBody", parent=styles["BodyText"], fontSize=9,
                              leading=14, textColor=INK, spaceAfter=7))
    styles.add(ParagraphStyle(name="IDOFoot", parent=styles["Normal"], fontSize=8,
                              leading=11, textColor=colors.HexColor("#617083")))
    margin=1.65*cm
    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=margin, rightMargin=margin,
                            topMargin=1.9*cm, bottomMargin=1.75*cm,
                            title="IDO | Informe de análisis de portafolios", author="IDO Investment Studio")
    available=A4[0]-2*margin
    story=[]
    P=lambda s, style="IDOBody": Paragraph(str(s), styles[style])
    def heading(name): story.append(P(name,"IDOH1"))
    def table(headers, rows, widths=None, font=7.5):
        data=[[P(str(c),"IDOFoot") for c in headers]] + [
              [P(str(c),"IDOFoot") for c in row] for row in rows]
        tbl=Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
        tbl.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#E8E9E9")),
            ("LINEBELOW",(0,0),(-1,0),.8,colors.HexColor(GOLD)),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white, LIGHT]),
            ("VALIGN",(0,0),(-1,-1),"TOP"),
            ("TOPPADDING",(0,0),(-1,-1),5), ("BOTTOMPADDING",(0,0),(-1,-1),5),
            ("LEFTPADDING",(0,0),(-1,-1),6), ("RIGHTPADDING",(0,0),(-1,-1),6),
        ]))
        story.append(tbl)
    def chart(filename, width=available):
        from reportlab.lib.utils import ImageReader
        fp=path.parent/filename
        iw, ih=ImageReader(str(fp)).getSize()
        h=width*ih/iw
        story.append(Image(str(fp), width=width, height=h))

    story.append(Spacer(1, .75*cm))
    story.append(P("IDO <font color='#A98C55'>/</font> INVESTMENT STUDIO", "IDOTitle"))
    story.append(P("Informe técnico de optimización de portafolios y región factible", "IDOH1"))
    story.append(HRFlowable(width="100%", thickness=1.2, color=colors.HexColor(GOLD)))
    story.append(Spacer(1,.35*cm))
    story.append(P(f"Generado: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}"))
    story.append(P(f"Universo: {', '.join(result.tickers)}"))
    story.append(P(f"Perfil: <b>{result.config['profile_label']}</b> · Estrategia: <b>{result.config['strategy_label']}</b>"))
    story.append(P(f"Intervalo: <b>{result.config['interval']}</b> · Precios coincidentes: <b>{result.config['n_observations']}</b>"))
    story.append(P(f"Periodo efectivo: {result.config['first_observation']} a {result.config['last_observation']}"))
    story.append(P("Fuente: Yahoo Finance, precios de cierre ajustados a eventos corporativos cuando el proveedor los facilita. El informe es una simulación basada en datos históricos, no una recomendación personalizada de inversión."))
    heading("1. Resumen ejecutivo")
    table(["Portafolio","Rend. anual", "Vol. anual", "Sharpe"],
          [[row["portfolio"], f"{row['return']:.2%}", f"{row['volatility']:.2%}",
            f"{row['sharpe']:.3f}" if pd.notna(row["sharpe"]) else "n/d"]
           for _, row in result.portfolios.iterrows()],
          [available*.36,available*.22,available*.22,available*.20])
    story.append(Spacer(1,.3*cm))
    heading("2. Ponderaciones por instrumento")
    table(["Activo"]+list(result.weights.index),
          [[t]+[f"{result.weights.loc[method,t]:.2%}" for method in result.weights.index]
           for t in result.tickers],
          [available*.20]+[available*.20]*4)
    heading("3. Metodología y fórmulas")
    story.append(P("Los rendimientos simples se calculan para cada intervalo; el vector de medias y la matriz de covarianzas se extrapolan al horizonte anual con un factor de sesiones/barras. La minimización se resuelve con SLSQP y restricciones de no negatividad."))
    eq_path=path.parent/"formulas_reporte.png"
    equation_image([
        r"r_t=\frac{P_t-P_{t-1}}{P_{t-1}}",
        r"\mu_{anual}=f\overline{r},\quad\Sigma_{anual}=f\,\mathrm{Cov}(r)",
        r"\min_{w}\ \frac{1}{2}w^{T}\Sigma w\quad \mathrm{s.a.}\quad \sum_i w_i=1,\ w_i\geq0",
        r"E[R_p]=w^{T}\mu,\quad\sigma_p=\sqrt{w^{T}\Sigma w}",
        r"S_p=\frac{E[R_p]-r_f}{\sigma_p}",
    ],eq_path)
    chart("formulas_reporte.png", width=available*.97)
    story.append(P(f"Factor anual empleado: <b>{result.config['periods_per_year']:,.1f}</b> barras/año. Tasa anual libre de riesgo: <b>{result.config['rf']:.2%}</b>. Nivel de significancia: <b>{result.config['alpha']:.2%}</b>."))
    story.append(P("La cartera por perfil está ubicada sobre la rama eficiente, a una fracción predefinida del recorrido de rendimiento entre el portafolio GMVP y el activo de mayor media histórica. Este criterio es una convención exploratoria; no equivale a una evaluación de idoneidad regulatoria."))
    heading("4. Región factible y frontera eficiente")
    chart("region_factible.png")
    story.append(P("La región representa todas las combinaciones long-only con pesos no negativos y suma igual a uno. El borde izquierdo minimiza riesgo para cada retorno. La CAL sólo se muestra si el Sharpe del portafolio tangente es positivo; presupone la disponibilidad hipotética de un activo sin riesgo a la tasa indicada."))
    heading("5. Diagnóstico de distribuciones")
    table(["Activo", "Media/barra", "Vol./barra", "Shapiro p", "Normalidad"],
          [[r.ticker,f"{r.mean_bar:.6f}",f"{r.vol_bar:.6f}",
            f"{r.shapiro_p:.4g}" if pd.notna(r.shapiro_p) else "n/d",
            "No rechazar" if r.normal_at_alpha else "Rechazar / n.d."] for r in result.stats.itertuples(index=False)],
          [available*.18,available*.21,available*.21,available*.17,available*.23])
    story.append(P("Shapiro-Wilk contrasta normalidad con el nivel alfa indicado; un valor p mayor que alfa NO demuestra que la distribución sea normal. Curtosis reportada: Pearson, con valor 3 para una normal. Para más de 5000 barras se evalúa una submuestra sistemática de 5000."))
    chart("histogramas.png")
    heading("6. Serie comparada de precios")
    chart("precios_comparados.png")
    heading("7. Rendimientos y dispersión anual")
    table(["Ticker","Media anual", "Vol. anual", "Score relativo", "Drawdown máx."],
          [[r.ticker,f"{r.return_annual:.2%}",f"{r.volatility_annual:.2%}",f"{r.score:.1f}/100",f"{r.max_drawdown:.2%}"]
           for r in result.rankings.itertuples(index=False)],
          [available*.20]*5)
    story.append(P("El ranking es relativo exclusivamente al grupo seleccionado. Combina volatilidad, drawdown, Sharpe y momentum de las barras recientes, con ponderaciones publicadas en el código. No evalúa fundamentales, valuación, liquidez, ni órdenes de compra o venta."))
    heading("8. Matriz completa: covarianza y correlación")
    story.append(P("Se presenta cada par ordenado de activos; se incluyen también las varianzas de la diagonal."))
    pair_rows=[]
    for i in result.tickers:
        for j in result.tickers:
            pair_rows.append([i,j, f"{result.sigma.loc[i,j]:.8f}",f"{result.correlation.loc[i,j]:.5f}"])
    table(["Activo i", "Activo j", "Cov. anual", "Correlación"], pair_rows,
          [available*.23,available*.23,available*.29,available*.25])
    heading("9. Advertencias y límites")
    for w in result.warnings:
        story.append(P("• " + w))
    for warning in result.config["assumptions"]:
        story.append(P("• " + warning))
    story.append(P("Los archivos CSV, JSON, gráficas y tabla de extremos de la región forman parte de la descarga ZIP y documentan los cálculos intermedios."))
    def on_page(canvas, document):
        canvas.setStrokeColor(colors.HexColor(GOLD))
        canvas.setLineWidth(.8)
        canvas.line(margin, A4[1]-1.35*cm, A4[0]-margin, A4[1]-1.35*cm)
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(INK)
        canvas.drawString(margin, A4[1]-1.1*cm, "IDO  /  RESEARCH & PORTFOLIO ANALYTICS")
        canvas.setFillColor(colors.HexColor("#687181"))
        canvas.drawString(margin, .9*cm, "Documento analítico · Uso educativo e informativo")
        canvas.drawRightString(A4[0]-margin, .9*cm, f"Página {document.page}")
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
