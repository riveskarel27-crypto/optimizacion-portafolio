"""Motor reproducible de análisis histórico y optimización long-only de Markowitz."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from itertools import combinations
from typing import Callable
import re

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import minimize


PROFILES = {
    "conservador": {"label": "Conservador", "fraction": 0.00, "score": (.55, .30, .10, .05)},
    "patrimonial": {"label": "Patrimonial", "fraction": 0.20, "score": (.40, .30, .20, .10)},
    "moderado": {"label": "Moderado", "fraction": 0.45, "score": (.25, .25, .35, .15)},
    "integral": {"label": "Integral", "fraction": 0.65, "score": (.15, .15, .40, .30)},
    "profesional": {"label": "Profesional", "fraction": 0.85, "score": (.10, .10, .35, .45)},
}
STRATEGIES = {
    "flash": {"label": "Flash / scalping", "interval": "1m", "days": 5, "max_days": 7, "bars_per_year": 252 * 390,
              "disclaimer": "Datos intradía de 1 minuto: horizonte corto, ruido y costos de ejecución pueden dominar; no representa señales de entrada."},
    "day": {"label": "Day trading", "interval": "5m", "days": 28, "max_days": 59, "bars_per_year": 252 * 78,
            "disclaimer": "Datos intradía: cierre de cada barra, spread y liquidez pueden afectar los resultados."},
    "swing": {"label": "Swing trading", "interval": "1h", "days": 55, "max_days": 59, "bars_per_year": 252 * 6.5,
              "disclaimer": "La anualización horaria asume 6.5 barras por sesión; es una aproximación y puede variar por bolsa."},
    "position": {"label": "Position trading", "interval": "1d", "days": 550, "max_days": None, "bars_per_year": 252,
                 "disclaimer": "Estimaciones basadas en cierres diarios ajustados; no incorporan costos, impuestos ni divisas."},
    "long": {"label": "Inversión a largo plazo", "interval": "1d", "days": 1095, "max_days": None, "bars_per_year": 252,
             "disclaimer": "Tres años permiten observar distintos entornos, pero no garantizan representatividad futura."},
}
TICKER_PATTERN = re.compile(r"^[A-Z0-9^][A-Z0-9.^=_-]{0,19}$")


class AnalysisError(ValueError):
    pass


def clean_tickers(raw: list[str]) -> list[str]:
    out = []
    for original in raw:
        t = original.strip().upper()
        if not TICKER_PATTERN.fullmatch(t):
            raise AnalysisError(f"Ticker no válido: {original!r}. Ejemplos: SPY, AAPL, AC.MX.")
        if t not in out:
            out.append(t)
    if not 2 <= len(out) <= 12:
        raise AnalysisError("Selecciona entre 2 y 12 instrumentos distintos.")
    return out


def resolve_period(strategy: str, start: str | None, end: str | None, auto_period: bool, today: date | None = None):
    if strategy not in STRATEGIES:
        raise AnalysisError("La estrategia seleccionada no es válida.")
    info = STRATEGIES[strategy]
    today = today or datetime.now(timezone.utc).date()
    if auto_period:
        end_d = today
        start_d = today - timedelta(days=info["days"])
    else:
        try:
            start_d, end_d = date.fromisoformat(start or ""), date.fromisoformat(end or "")
        except ValueError as exc:
            raise AnalysisError("Ingresa dos fechas válidas (AAAA-MM-DD).") from exc
    if start_d >= end_d:
        raise AnalysisError("La fecha inicial debe ser anterior a la final.")
    if end_d > today:
        raise AnalysisError("La fecha final no puede estar en el futuro.")
    if info["max_days"] and ((end_d - start_d).days > info["max_days"] or start_d < today - timedelta(days=info["max_days"]+1)):
        raise AnalysisError(f"Yahoo limita la disponibilidad de {info['interval']} reciente. Prueba como máximo {info['max_days']} días hasta la fecha actual, o cambia a un horizonte diario.")
    # yfinance toma end como EXCLUSIVO: se añade 1 día para respetar el día final elegido.
    return start_d.isoformat(), end_d.isoformat(), (end_d + timedelta(days=1)).isoformat(), info


def extract_close(frame: pd.DataFrame, ticker: str) -> pd.Series:
    if frame is None or frame.empty:
        raise AnalysisError(f"Yahoo Finance no devolvió datos para {ticker}.")
    if isinstance(frame.columns, pd.MultiIndex):
        if "Close" in frame.columns.get_level_values(0):
            value = frame["Close"]
        elif "Close" in frame.columns.get_level_values(1):
            value = frame.xs("Close", axis=1, level=1)
        else:
            raise AnalysisError(f"No hay precio de cierre disponible para {ticker}.")
        if isinstance(value, pd.DataFrame):
            value = value[ticker] if ticker in value.columns else value.iloc[:, 0]
    else:
        if "Close" not in frame.columns:
            raise AnalysisError(f"No hay precio de cierre disponible para {ticker}.")
        value = frame["Close"]
    close = pd.to_numeric(value, errors="coerce")
    close = close.replace([np.inf, -np.inf], np.nan).dropna()
    close = close[close > 0]
    if len(close) < 3:
        raise AnalysisError(f"No hay suficientes precios válidos de {ticker}.")
    close.name = ticker
    return close


def load_prices(tickers: list[str], start: str, end_exclusive: str, interval: str,
                download: Callable | None = None) -> tuple[pd.DataFrame, list[str]]:
    if download is None:
        try:
            import yfinance as yf
        except ImportError as exc:
            raise AnalysisError("Instala las dependencias de requirements.txt para acceder a Yahoo Finance.") from exc
        download = yf.download
    series = []
    counts = []
    for ticker in tickers:
        try:
            frame = download(ticker, start=start, end=end_exclusive, interval=interval,
                             auto_adjust=True, progress=False, threads=False, timeout=20)
            close = extract_close(frame, ticker)
        except AnalysisError:
            raise
        except Exception as exc:
            raise AnalysisError(f"Error al descargar {ticker} de Yahoo Finance: {exc}") from exc
        idx = pd.DatetimeIndex(close.index)
        if interval != "1d":
            # Sincroniza mercados cotizados en distintas zonas horarias.
            if idx.tz is None:
                raise AnalysisError(f"Yahoo devolvió barras intradía sin zona horaria para {ticker}.")
            idx = idx.tz_convert("UTC")
        else:
            idx = idx.tz_localize(None).normalize() if idx.tz is None else idx.tz_localize(None).normalize()
        close.index = idx
        close = close.loc[~close.index.duplicated(keep="last")].sort_index()
        counts.append(len(close))
        series.append(close)
    prices = pd.concat(series, axis=1, join="inner").dropna()
    if prices.shape[0] < 31:
        raise AnalysisError(f"Sólo hay {len(prices)} precios coincidentes entre los instrumentos; se necesitan al menos 31 para un análisis razonable.")
    warnings = []
    overlap = len(prices) / min(counts)
    if overlap < .8:
        warnings.append(f"Coincide sólo el {overlap:.1%} del historial más corto; los cierres de distintos mercados/horarios pueden no coincidir.")
    if interval != "1d":
        warnings.append("La volatilidad anual intradía se extrapola por barras esperadas y supone sincronía de cotización. Flash/day no incorpora spread, slippage ni microestructura.")
    if prices.index.max().date() < (date.today() - timedelta(days=7)):
        warnings.append("Los últimos datos disponibles son antiguos: revisa días inhábiles y disponibilidad del proveedor.")
    return prices, warnings


def annual_moments(returns: pd.DataFrame, factor: float) -> tuple[np.ndarray, np.ndarray]:
    mu = returns.mean().to_numpy(dtype=float) * factor
    cov = returns.cov().to_numpy(dtype=float) * factor
    cov = (cov + cov.T) / 2
    eig = np.linalg.eigvalsh(cov)
    if eig.min() < -1e-7:
        raise AnalysisError("La matriz de covarianza no es semidefinida positiva; verifica los datos.")
    if eig.min() < 0:
        cov += np.eye(len(mu)) * (-eig.min() + 1e-12)
    return mu, cov


def portfolio_metrics(w: np.ndarray, mu: np.ndarray, cov: np.ndarray, rf: float):
    y = float(np.dot(w, mu))
    variance = max(0.0, float(w @ cov @ w))
    sigma = float(np.sqrt(variance))
    return {"return": y, "variance": variance, "volatility": sigma,
            "sharpe": float((y - rf) / sigma) if sigma > 1e-12 else None}


def optimize_gmvp(cov: np.ndarray) -> np.ndarray:
    n = cov.shape[0]
    initial = np.ones(n) / n
    res = minimize(lambda w: 500 * (w @ cov @ w), initial,
                   jac=lambda w: 1000 * cov @ w, method="SLSQP",
                   constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1, "jac": lambda w: np.ones(n)}],
                   bounds=[(0, 1)] * n, options={"ftol": 1e-12, "maxiter": 1200})
    return validate_solution(res, expected_return=None, mu=None)


def validate_solution(res, expected_return: float | None, mu: np.ndarray | None) -> np.ndarray:
    w = np.asarray(res.x, dtype=float)
    if not res.success or np.any(w < -2e-6) or np.any(w > 1 + 2e-6) or abs(w.sum() - 1) > 2e-6:
        raise AnalysisError(f"La optimización no convergió con restricciones válidas: {res.message}")
    if expected_return is not None and mu is not None and abs(mu @ w - expected_return) > 2e-5:
        raise AnalysisError("La optimización no pudo satisfacer el rendimiento objetivo solicitado.")
    return np.clip(w, 0, 1) / np.clip(w, 0, 1).sum()


def optimize_target(mu: np.ndarray, cov: np.ndarray, target: float) -> np.ndarray:
    n = len(mu)
    lo, hi = int(np.argmin(mu)), int(np.argmax(mu))
    if float(mu[hi] - mu[lo]) < 1e-12:
        return optimize_gmvp(cov)
    q = np.clip((target - mu[lo]) / (mu[hi] - mu[lo]), 0, 1)
    x0 = np.zeros(n)
    x0[lo], x0[hi] = 1 - q, q
    res = minimize(lambda w: 500 * (w @ cov @ w), x0, jac=lambda w: 1000 * (cov @ w),
                   method="SLSQP", bounds=[(0, 1)] * n,
                   constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1,
                                 "jac": lambda w: np.ones(n)},
                                {"type": "eq", "fun": lambda w: 100 * (mu @ w - target),
                                 "jac": lambda w: 100 * mu}],
                   options={"ftol": 1e-11, "maxiter": 1800})
    return validate_solution(res, expected_return=target, mu=mu)


def optimize_tangent(mu: np.ndarray, cov: np.ndarray, rf: float, gmvp: np.ndarray) -> np.ndarray:
    n = len(mu)
    def objective(w):
        risk = max(1e-10, np.sqrt(max(0., float(w @ cov @ w))))
        return -float((mu @ w - rf) / risk)
    candidates = [gmvp, np.ones(n)/n] + [np.eye(n)[k] for k in range(n)]
    viable = []
    for x0 in candidates:
        sol = minimize(objective, x0, method="SLSQP", bounds=[(0, 1)] * n,
                       constraints=[{"type":"eq", "fun":lambda w: w.sum() - 1}],
                       options={"ftol":1e-11, "maxiter":1000})
        try:
            viable.append(validate_solution(sol, None, None))
        except AnalysisError:
            pass
    if not viable:
        raise AnalysisError("No se pudo determinar el portafolio de máximo Sharpe.")
    return min(viable, key=objective)


def max_risk_at_return(target: float, mu: np.ndarray, cov: np.ndarray) -> float:
    """Máximo de forma cuadrática convexa sobre la sección simplex ∩ hiperplano.
    Los vértices de la sección tienen soporte de hasta 2 activos."""
    n = len(mu)
    possibilities = []
    for i in range(n):
        if abs(mu[i] - target) < 1e-9:
            possibilities.append(float(np.sqrt(max(0, cov[i, i]))))
    for i, j in combinations(range(n), 2):
        delta = mu[i] - mu[j]
        if abs(delta) < 1e-12:
            continue
        a = (target - mu[j]) / delta
        if -1e-8 <= a <= 1 + 1e-8:
            w = np.zeros(n)
            w[i], w[j] = np.clip(a, 0, 1), 1 - np.clip(a, 0, 1)
            possibilities.append(float(np.sqrt(max(0, w @ cov @ w))))
    if not possibilities:
        raise AnalysisError("No se encontraron carteras extremas para construir la región factible.")
    return max(possibilities)


def build_frontier(mu: np.ndarray, cov: np.ndarray, gmvp: np.ndarray, points: int = 84) -> pd.DataFrame:
    lo, hi = float(mu.min()), float(mu.max())
    targets = np.linspace(lo, hi, points) if hi - lo > 1e-11 else np.array([lo])
    gmvp_return = float(mu @ gmvp)
    data = []
    for y in targets:
        if abs(y - gmvp_return) < 1e-10:
            w = gmvp
        else:
            w = optimize_target(mu, cov, float(y))
        left = float(np.sqrt(max(0, w @ cov @ w)))
        right = max_risk_at_return(float(y), mu, cov)
        data.append({"return": float(y), "min_volatility": left,
                     "max_volatility": max(left, right), "efficient": bool(y >= gmvp_return - 1e-10)})
    return pd.DataFrame(data)


def descriptive_stats(returns: pd.DataFrame, factor: float, alpha: float) -> pd.DataFrame:
    rows = []
    for ticker in returns.columns:
        s = returns[ticker].dropna()
        if len(s) > 5000:
            # scipy advierte falta de precisión del p-valor para N>5000.
            positions = np.linspace(0, len(s)-1, 5000, dtype=int)
            s_sw = s.iloc[positions]
        else:
            s_sw = s
        if s_sw.nunique() < 2:
            sw, p = np.nan, np.nan
        else:
            sw, p = stats.shapiro(s_sw)
        rows.append({"ticker": ticker, "mean_bar": float(s.mean()),
                     "vol_bar": float(s.std(ddof=1)), "skewness": float(s.skew()),
                     "kurtosis_pearson": float(s.kurt() + 3), "shapiro_w": float(sw),
                     "shapiro_p": float(p), "normal_at_alpha": bool(p > alpha) if np.isfinite(p) else None,
                     "n": int(len(s)), "n_shapiro": int(len(s_sw)),
                     "mean_annual": float(s.mean() * factor),
                     "vol_annual": float(s.std(ddof=1) * np.sqrt(factor))})
    return pd.DataFrame(rows)


def drawdown_series(prices: pd.DataFrame):
    return prices / prices.cummax() - 1


def asset_rankings(returns: pd.DataFrame, prices: pd.DataFrame, mu: np.ndarray,
                   cov: np.ndarray, rf: float, profile: str, strategy: str) -> pd.DataFrame:
    """Puntaje relativo y transparente. No infiere recomendaciones personalizadas reguladas."""
    vol = np.sqrt(np.maximum(np.diag(cov), 0))
    sh = (mu - rf) / np.maximum(vol, 1e-12)
    dd = drawdown_series(prices).min().to_numpy(dtype=float)
    lookback = min(20, max(2, len(prices) // 4))
    momentum = (prices.iloc[-1] / prices.iloc[-lookback] - 1).to_numpy(dtype=float)
    def norm(a):
        a = np.asarray(a, dtype=float)
        a = np.nan_to_num(a, nan=0, posinf=0, neginf=0)
        span = a.max() - a.min()
        return np.full(len(a), 0.5) if span < 1e-12 else (a-a.min())/span
    safety, recovery, quality, trend = norm(-vol), norm(dd), norm(np.clip(sh, -5, 5)), norm(momentum)
    weights = np.array(PROFILES[profile]["score"], dtype=float)
    # El trading corto pondera mayormente momentum reciente, SIN convertirlo en señales de trading.
    trend_add = {"flash": .30, "day": .22, "swing": .12, "position": .05, "long": .00}[strategy]
    weights = weights * (1 - trend_add)
    weights[3] += trend_add
    score = 100*(weights[0]*safety + weights[1]*recovery + weights[2]*quality + weights[3]*trend)
    return pd.DataFrame({"ticker": prices.columns, "score": score, "return_annual": mu,
                         "volatility_annual": vol, "sharpe": sh, "max_drawdown": dd,
                         "recent_momentum": momentum}).sort_values("score", ascending=False).reset_index(drop=True)


@dataclass
class Result:
    tickers: list[str]
    prices: pd.DataFrame
    returns: pd.DataFrame
    stats: pd.DataFrame
    mu: pd.Series
    sigma: pd.DataFrame
    correlation: pd.DataFrame
    frontier: pd.DataFrame
    portfolios: pd.DataFrame
    rankings: pd.DataFrame
    weights: pd.DataFrame
    warnings: list[str]
    config: dict


def calculate(prices: pd.DataFrame, profile: str = "moderado", strategy: str = "long",
              rf: float = .04, alpha: float = .05, warnings: list[str] | None = None) -> Result:
    if profile not in PROFILES or strategy not in STRATEGIES:
        raise AnalysisError("Perfil o estrategia no disponibles.")
    if not 0 <= rf < 1 or not 0 < alpha < 1:
        raise AnalysisError("Tasa libre de riesgo o nivel de significancia fuera de rango.")
    tickers = list(prices.columns)
    if len(tickers) < 2:
        raise AnalysisError("Se requieren como mínimo dos instrumentos.")
    if prices.shape[0] < 31:
        raise AnalysisError("Se necesitan al menos 31 precios coincidentes.")
    returns = prices.pct_change(fill_method=None).replace([np.inf,-np.inf],np.nan).dropna()
    if returns.isna().any().any() or len(returns) < 30:
        raise AnalysisError("No hay suficientes rendimientos válidos.")
    factor = STRATEGIES[strategy]["bars_per_year"]
    mu, sigma = annual_moments(returns, factor)
    gmvp = optimize_gmvp(sigma)
    target = float(mu @ gmvp + PROFILES[profile]["fraction"] * (mu.max() - mu @ gmvp))
    selected = optimize_target(mu, sigma, target) if abs(target - mu @ gmvp) > 1e-10 else gmvp.copy()
    tangent = optimize_tangent(mu, sigma, rf, gmvp)
    equal = np.ones(len(tickers)) / len(tickers)
    ws = {"Perfil recomendado": selected, "Mínima varianza": gmvp, "Máximo Sharpe": tangent, "Equiponderado": equal}
    frontier = build_frontier(mu, sigma, gmvp)
    p_rows = []
    for name, w in ws.items():
        m = portfolio_metrics(w, mu, sigma, rf)
        p_rows.append({"portfolio": name, **m, "feasible": bool(abs(w.sum()-1)<1e-7 and np.all(w >= -1e-8)),
                       "weights_sum": float(w.sum())})
    portfolio_df = pd.DataFrame(p_rows)
    weights = pd.DataFrame(ws, index=tickers).T
    stats_df = descriptive_stats(returns, factor, alpha)
    rankings = asset_rankings(returns, prices, mu, sigma, rf, profile, strategy)
    risks = np.sqrt(np.maximum(np.diag(sigma), 0))
    warnings = list(warnings or [])
    if np.linalg.matrix_rank(sigma, tol=1e-10) < len(tickers):
        warnings.append("Covarianza singular o casi singular: algunos activos presentan series muy similares.")
    if np.isfinite(stats_df["shapiro_p"]).any() and (stats_df["normal_at_alpha"] == False).any():
        warnings.append("Shapiro-Wilk rechaza normalidad para uno o más activos; la optimización de media-varianza no presupone normalidad, pero las colas merecen análisis adicional.")
    if (risks == 0).any():
        warnings.append("Hay activos sin variación observable; Sharpe y covarianzas pueden ser inestables.")
    if (mu < 0).any():
        warnings.append("Uno o más activos tienen rendimiento medio histórico negativo; la selección de la frontera sigue siendo una extrapolación, no un pronóstico fiable.")
    warnings.append(STRATEGIES[strategy]["disclaimer"])
    config = {"profile": profile, "profile_label": PROFILES[profile]["label"],
              "strategy": strategy, "strategy_label": STRATEGIES[strategy]["label"],
              "interval": STRATEGIES[strategy]["interval"], "periods_per_year": factor,
              "rf": rf, "alpha": alpha, "n_observations": len(prices),
              "first_observation": str(prices.index.min()), "last_observation": str(prices.index.max()),
              "source": "Yahoo Finance (yfinance), Close con auto_adjust=True", "assumptions": [
                  "No se permiten posiciones cortas: 0 <= w_i <= 1 y suma(w)=1.",
                  "Se usan rendimientos simples; media anual = media por barra por factor.",
                  "Volatilidad anual = volatilidad por barra por raiz(factor).",
                  "La tasa libre de riesgo se expresa en términos anuales.",
                  "No se modelan comisiones, impuestos, riesgo cambiario, slippage ni restricciones de lotes.",
                  "El rango temporal y los activos elegidos generan sesgo de selección; no hay validación fuera de muestra.",
              ]}
    return Result(tickers, prices, returns, stats_df, pd.Series(mu,index=tickers,name="mu_anual"),
                  pd.DataFrame(sigma,index=tickers,columns=tickers), returns.corr(), frontier,
                  portfolio_df, rankings, weights, warnings, config)


def serialize(result: Result, run_id: str) -> dict:
    def num(v):
        if v is None or pd.isna(v) or not np.isfinite(float(v)):
            return None
        return float(v)
    def records(frame):
        return [{k: num(v) if isinstance(v, (float, int, np.floating, np.integer)) and not isinstance(v, (bool, np.bool_)) else
                 (bool(v) if isinstance(v, (np.bool_, bool)) else v)
                 for k,v in row.items()} for row in frame.to_dict("records")]
    return {"run_id": run_id, "config": result.config, "warnings": result.warnings,
            "tickers": result.tickers, "stats": records(result.stats),
            "rankings": records(result.rankings), "portfolios": records(result.portfolios),
            "weights": {name: {ticker: num(v) for ticker, v in row.items()}
                        for name, row in result.weights.iterrows()},
            "mu": {t: num(x) for t, x in result.mu.items()},
            "sigma": [[num(v) for v in row] for row in result.sigma.to_numpy()],
            "correlation": [[num(v) for v in row] for row in result.correlation.to_numpy()],
            "frontier": records(result.frontier),
            "assets": [{"ticker": t, "return": num(result.mu[t]),
                        "volatility": num(np.sqrt(max(0,result.sigma.loc[t,t])))} for t in result.tickers]}
