'use strict';
const $ = (id) => document.getElementById(id);
const state = { tickers: ['DUK', 'LQD', 'KIMBERA.MX', 'AC.MX'], data: null, chart: 'region', busy: false };
const colorPalette = ['#B99A64','#2D4651','#718D91','#D9D8C9','#657386','#B77868','#76927A','#C2C6C4','#9D78A6','#D7AF82','#728CA7','#8A7965'];
const durations = {
 flash: {days:5,title:'Ventana sugerida · 5 días',label:'Intervalo de 1 minuto',explain:'Yahoo sólo ofrece una ventana intradía muy reciente. No es apropiado inferir rentabilidad estable a futuro con unos días.'},
 day: {days:28,title:'Ventana sugerida · 28 días',label:'Intervalo de 5 minutos',explain:'Ventana reciente para estudiar fluctuaciones intradía; no incluye spread, liquidez ni slippage.'},
 swing: {days:55,title:'Ventana sugerida · 55 días',label:'Intervalo de 1 hora',explain:'Historial reciente intradía para explorar variaciones de corto plazo, con anualización aproximada.'},
 position: {days:550,title:'Ventana sugerida · 18 meses',label:'Intervalo diario',explain:'Incluye distintas fases de mercado con un horizonte adecuado para posiciones de varias semanas o meses.'},
 long: {days:1095,title:'Ventana sugerida · 36 meses',label:'Intervalo diario',explain:'Un historial de tres años permite estudiar más condiciones de mercado, aunque no garantiza proyecciones estables.'}
};
const suggestions = {
 conservador:['BND','IEF','LQD','SHY','SGOV'], patrimonial:['SPY','BND','GLD','IEF','LQD'],
 moderado:['SPY','QQQ','LQD','EWW','GLD'], integral:['SPY','QQQ','IWM','EWW','XLV'],
 profesional:['QQQ','IWM','XLK','SPY','SMH']
};
const fmtPct = (v, digits=2) => v == null || !isFinite(v) ? 'n/d' : `${(100*v).toLocaleString('es-MX',{minimumFractionDigits:digits,maximumFractionDigits:digits})}%`;
const fmtNum = (v, digits=3) => v == null || !isFinite(v) ? 'n/d' : Number(v).toLocaleString('es-MX',{minimumFractionDigits:digits,maximumFractionDigits:digits});
const escapeHTML = (s) => String(s).replace(/[&<>"']/g, (c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const isoDay = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
function setDaysBefore(days){const end=new Date();const start=new Date(end);start.setDate(start.getDate()-days);$('end-date').value=isoDay(end);$('start-date').value=isoDay(start);$('end-date').max=isoDay(end)}
function updateTickerChips(){
 $('ticker-chips').replaceChildren();
 state.tickers.forEach(t=>{
  const node=document.createElement('span');node.className='ticker-chip';
  const name=document.createElement('span');name.textContent=t;node.append(name);
  const remove=document.createElement('button');remove.type='button';remove.title=`Quitar ${t}`;remove.setAttribute('aria-label',`Quitar ${t}`);remove.textContent='×';remove.onclick=()=>{state.tickers=state.tickers.filter(v=>v!==t);updateTickerChips();updateSuggestions()};node.append(remove);
  $('ticker-chips').append(node);
 });
 $('ticker-count').textContent=`${state.tickers.length} / 12`;
}
function addTicker(value){
 const t=String(value||'').trim().toUpperCase();
 if(!/^[A-Z0-9^][A-Z0-9.^=_-]{0,19}$/.test(t)){showError('Escribe un ticker válido (por ejemplo, AAPL, SPY o AC.MX).');return}
 if(state.tickers.includes(t)){$('ticker-input').value='';return}
 if(state.tickers.length>=12){showError('Se admiten como máximo 12 instrumentos por análisis.');return}
 state.tickers.push(t);$('ticker-input').value='';hideError();updateTickerChips();updateSuggestions();
}
function updateSuggestions(){
 $('suggestions').replaceChildren();
 let list=suggestions[$('profile').value]||[];
 // Las ideas se ofrecen para investigar, no se presentan como activos aprobados por el perfil.
 list.filter(t=>!state.tickers.includes(t)).forEach(t=>{
  const b=document.createElement('button');b.textContent=`+ ${t}`;b.type='button';b.onclick=()=>addTicker(t);$('suggestions').append(b)
 });
}
function updatePeriod(){
 const s=durations[$('strategy').value];
 $('period-title').textContent=s.title;$('period-explainer').textContent=s.explain;$('interval-label').textContent=s.label;
 const automatic=document.querySelector('input[name="periodmode"]:checked').value==='auto';
 $('start-date').disabled=automatic;$('end-date').disabled=automatic;
 if(automatic)setDaysBefore(s.days);
 else if($('strategy').value!=='long' && $('strategy').value!=='position') $('period-explainer').textContent += ' Recuerda los límites intradía de Yahoo.';
}
function showError(message){$('error-text').textContent=message;$('error').classList.remove('hidden')}
function hideError(){$('error').classList.add('hidden')}
function setBusy(value){state.busy=value;$('submit-button').disabled=value;$('submit-label').textContent=value?'Calculando y preparando documentos…':'Ejecutar análisis cuantitativo';$('loading').classList.toggle('hidden',!value);if(value){$('welcome').classList.add('hidden');$('results').classList.add('hidden')}}
function portfolioRow(row){
 return `<tr class="${row.portfolio==='Perfil recomendado'?'highlight-row':''}"><td>${escapeHTML(row.portfolio)}</td><td class="${row.return>=0?'positive':'negative'}">${fmtPct(row.return)}</td><td>${fmtPct(row.volatility)}</td><td>${fmtNum(row.variance,6)}</td><td>${fmtNum(row.sharpe)}</td><td><span class="mini-status">${row.feasible?'Válidas':'Revisar'}</span></td></tr>`;
}
function renderAllocation(d){
 const w=d.weights['Perfil recomendado'];const ordered=Object.entries(w).sort((a,b)=>b[1]-a[1]);
 let previous=0;const wedges=[];
 ordered.forEach(([t,v],i)=>{const next=previous+v*100;wedges.push(`${colorPalette[d.tickers.indexOf(t)%colorPalette.length]} ${previous.toFixed(5)}% ${next.toFixed(5)}%`);previous=next});
 $('donut').style.background=`conic-gradient(${wedges.join(',')})`;
 $('allocation-rows').innerHTML=ordered.map(([t,v])=>{let c=colorPalette[d.tickers.indexOf(t)%colorPalette.length];return `<div class="alloc-row"><span class="alloc-dot" style="background:${c}"></span><span class="alloc-name">${escapeHTML(t)}</span><div class="alloc-bar-wrap"><div class="alloc-bar" style="width:${Math.max(0,v*100)}%;background:${c}"></div></div><span class="alloc-percent">${fmtPct(v)}</span></div>`}).join('');
 const profileTitles={conservador:'Prioridad: mínima varianza',patrimonial:'Prioridad: preservación patrimonial',moderado:'Prioridad: balance riesgo–retorno',integral:'Prioridad: crecimiento diversificado',profesional:'Prioridad: mayor rendimiento objetivo'};
 $('selected-portfolio-title').textContent=profileTitles[d.config.profile]||'Composición optimizada';
 const fraction={conservador:'0%',patrimonial:'20%',moderado:'45%',integral:'65%',profesional:'85%'};
 $('profile-explainer').textContent=`Asignación sobre el borde de mínima varianza a un rendimiento objetivo ubicado al ${fraction[d.config.profile]} del recorrido entre el GMVP y la mayor media de los activos. Es una regla matemática exploratoria, no un cuestionario formal de idoneidad financiera.`;
}
function chartPath(kind){return `/api/download/${encodeURIComponent(state.data.run_id)}/${kind}`}
function switchChart(kind){
 const desc={region:'Conjunto long-only: todas las carteras posibles dentro de los límites de retorno y volatilidad. Los puntos muestran modelos de asignación y activos aislados.',hist:'Histogramas de rendimientos por barra frente a curvas normales teóricas ajustadas. La prueba de normalidad se reporta por separado.',prices:'Precio de cierre ajustado, normalizado a 100 en la primera fecha común. No debe interpretarse como rentabilidad después de impuestos o divisas.'};
 state.chart=kind;$('result-chart').src=chartPath(kind);$('result-chart').alt=desc[kind];$('png-download').href=chartPath(kind);$('png-download').download=kind+'.png';$('chart-description').textContent=desc[kind];
 document.querySelectorAll('[data-chart]').forEach(b=>{const selected=b.dataset.chart===kind;b.classList.toggle('active',selected);b.setAttribute('aria-selected',String(selected))})
}
function renderMatrix(d){
 const type=$('matrix-type').value;const vals=d[type];
 const header=d.tickers.map(t=>`<th>${escapeHTML(t)}</th>`).join('');
 const rows=d.tickers.map((t,i)=>`<tr><td>${escapeHTML(t)}</td>`+d.tickers.map((_,j)=>{
  const v=vals[i][j];let bg='#fff';
  if(type==='correlation' && v!=null){const strength=Math.abs(v);bg=v>=0?`rgba(88,146,117,${(.06+strength*.23).toFixed(3)})`:`rgba(189,108,101,${(.06+strength*.23).toFixed(3)})`}
  return `<td style="background:${bg}">${fmtNum(v,type==='correlation'?3:6)}</td>`;
 }).join('')+'</tr>').join('');
 $('matrix-container').innerHTML=`<table class="matrix"><thead><tr><th>${type==='correlation'?'ρ':'Σ'}</th>${header}</tr></thead><tbody>${rows}</tbody></table>`;
}
function renderResults(d){
 state.data=d;
 const p=d.portfolios.find(row=>row.portfolio==='Perfil recomendado');
 $('metric-return').textContent=fmtPct(p.return);
 $('metric-vol').textContent=fmtPct(p.volatility);
 $('metric-sharpe').textContent=fmtNum(p.sharpe);
 $('metric-n').textContent=Number(d.config.n_observations).toLocaleString('es-MX');
 $('analysis-meta').textContent=`${d.tickers.length} instrumentos · ${d.config.strategy_label} · ${d.config.first_observation.slice(0,10)} a ${d.config.last_observation.slice(0,10)} · ${d.config.interval}`;
 renderAllocation(d);
 $('portfolio-table').querySelector('tbody').innerHTML=d.portfolios.map(portfolioRow).join('');
 $('stat-table').querySelector('tbody').innerHTML=d.stats.map(x=>{
  const conclusion=x.normal_at_alpha===null?'No evaluable':x.normal_at_alpha?'No rechazar H₀':'Rechazar H₀';
  return `<tr><td>${escapeHTML(x.ticker)}</td><td>${fmtNum(x.mean_bar,6)}</td><td>${fmtNum(x.vol_bar,6)}</td><td>${fmtNum(x.skewness)}</td><td>${fmtNum(x.kurtosis_pearson)}</td><td>${fmtNum(x.shapiro_p,5)}</td><td>${conclusion}</td></tr>`
 }).join('');
 $('rank-table').querySelector('tbody').innerHTML=d.rankings.map((x,i)=>{
  return `<tr><td class="rank-number">${String(i+1).padStart(2,'0')}</td><td>${escapeHTML(x.ticker)}</td><td><b>${fmtNum(x.score,1)}</b> / 100</td><td>${fmtPct(x.return_annual)}</td><td>${fmtPct(x.volatility_annual)}</td><td>${fmtPct(x.max_drawdown)}</td><td>${fmtPct(x.recent_momentum)}</td></tr>`
 }).join('');
 $('ranking-explainer').textContent=`El orden clasifica solamente los instrumentos descargados según volatilidad, drawdown, Sharpe y momentum reciente; la ponderación se ajusta al perfil ${d.config.profile_label.toLowerCase()} y estilo ${d.config.strategy_label.toLowerCase()}. Los puntajes son relativos al grupo y no constituyen señales para abrir operaciones.`;
 renderMatrix(d);switchChart('region');
 $('warnings-list').replaceChildren();
 d.warnings.concat(d.config.assumptions||[]).forEach(w=>{const li=document.createElement('li');li.textContent=w;$('warnings-list').append(li)});
 $('pdf-link').href=chartPath('pdf');$('zip-link').href=chartPath('zip');
 $('results').classList.remove('hidden');
 $('resultados').scrollIntoView({behavior:'smooth',block:'start'});
}
async function handleSubmit(e){
 e.preventDefault();if(state.busy)return;hideError();
 if(state.tickers.length<2){showError('Selecciona al menos dos instrumentos diferentes.');return}
 const auto=document.querySelector('input[name="periodmode"]:checked').value==='auto';
 const body={tickers:state.tickers,profile:$('profile').value,strategy:$('strategy').value,auto_period:auto,
  start_date:auto?null:$('start-date').value,end_date:auto?null:$('end-date').value,
  risk_free_rate:Number($('rf').value),alpha:Number($('alpha').value)};
 if(!auto&&(!body.start_date||!body.end_date)){showError('Completa ambas fechas para usar un periodo personalizado.');return}
 setBusy(true);
 try{
  const response=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const payload=await response.json();
  if(!response.ok)throw new Error(typeof payload.detail==='string'?payload.detail:'No se pudieron obtener datos válidos del proveedor.');
  setBusy(false);renderResults(payload);
 }catch(err){setBusy(false);showError(err.message||'Fallo inesperado al analizar.');$('error').scrollIntoView({behavior:'smooth',block:'center'});if(!state.data)$('welcome').classList.remove('hidden')}
}
function start(){
 $('add-ticker').onclick=()=>addTicker($('ticker-input').value);
 $('ticker-input').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===','){e.preventDefault();addTicker($('ticker-input').value)}});
 $('profile').addEventListener('change',updateSuggestions);
 $('strategy').addEventListener('change',updatePeriod);
 document.querySelectorAll('input[name="periodmode"]').forEach(x=>x.addEventListener('change',updatePeriod));
 $('matrix-type').addEventListener('change',()=>{if(state.data)renderMatrix(state.data)});
 document.querySelectorAll('[data-chart]').forEach(b=>b.addEventListener('click',()=>{if(state.data)switchChart(b.dataset.chart)}));
 $('analysis-form').addEventListener('submit',handleSubmit);
 updateTickerChips();updateSuggestions();updatePeriod();
}
document.addEventListener('DOMContentLoaded',start);
