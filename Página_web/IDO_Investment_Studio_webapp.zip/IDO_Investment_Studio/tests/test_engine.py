from datetime import date
from pathlib import Path
import io
import zipfile

import numpy as np
import pandas as pd
import pytest

from app.engine import (clean_tickers, resolve_period, calculate, optimize_gmvp, optimize_target,
                         max_risk_at_return, portfolio_metrics, load_prices, AnalysisError)
from app.reporting import export_run


def synthetic_prices(n=180):
    rng=np.random.default_rng(982134)
    mat=rng.normal(size=(n,4))*np.array([.009,.003,.011,.008])+np.array([.00045,.0001,.0003,.0006])
    prices=100*np.cumprod(1+mat,axis=0)
    return pd.DataFrame(prices,columns=['DUK','LQD','KIMBERA.MX','AC.MX'],
                        index=pd.date_range('2025-01-01',periods=n,freq='B'))


def test_tickers():
    assert clean_tickers(['spy',' AAPL ', 'spy'])==['SPY','AAPL']
    with pytest.raises(AnalysisError): clean_tickers(['ONLY'])
    with pytest.raises(AnalysisError): clean_tickers(['AAPL','../../etc/passwd'])


def test_dates():
    start,end,exclusive,info=resolve_period('long',None,None,True,today=date(2026,10,26))
    assert end=='2026-10-26' and exclusive=='2026-10-27'
    with pytest.raises(AnalysisError): resolve_period('flash','2026-01-01','2026-09-01',False,today=date(2026,10,26))


def test_optimization_and_region():
    x=synthetic_prices()
    out=calculate(x,'moderado','long')
    assert (out.weights.values>=-1e-8).all()
    assert np.allclose(out.weights.sum(axis=1),1,atol=1e-8)
    assert out.portfolios['feasible'].all()
    assert (out.frontier['min_volatility']<=out.frontier['max_volatility']+1e-9).all()
    assert out.frontier['efficient'].any()
    np.testing.assert_allclose(out.sigma.values, out.sigma.values.T, atol=1e-12)
    assert len(out.stats)==4
    assert len(out.rankings)==4
    gmvp=out.weights.loc['Mínima varianza'].to_numpy()
    y=float(out.mu.values@gmvp)
    assert max_risk_at_return(y,out.mu.to_numpy(),out.sigma.to_numpy())>=portfolio_metrics(gmvp,out.mu.to_numpy(),out.sigma.to_numpy(),.04)['volatility']-1e-8


def test_equal_mu_and_two_assets():
    mu=np.array([.08,.08])
    cov=np.array([[.04,.0],[.0,.09]])
    out=optimize_target(mu,cov,.08)
    assert np.isclose(out.sum(),1)
    assert max_risk_at_return(.08,mu,cov)==pytest.approx(.3)
    gmvp=optimize_gmvp(cov)
    assert .6<gmvp[0]<.8


def test_download_multiindex_mock():
    idx=pd.date_range('2025-01-01', periods=45, freq='B')
    def download(ticker, **kw):
        return pd.DataFrame({('Close',ticker):np.linspace(100,110,45),('Volume',ticker):np.ones(45)},index=idx)
    prices,w=load_prices(['SPY','QQQ'],'2025-01-01','2025-04-01','1d',download)
    assert prices.shape==(45,2)
    assert list(prices.columns)==['SPY','QQQ']


def test_export_pdf_and_zip(tmp_path):
    result=calculate(synthetic_prices(95),'conservador','long')
    export_run(result,tmp_path,'9999')
    path=tmp_path/'Informe_IDO.pdf'
    assert path.stat().st_size>15000
    with open(path,'rb') as f: assert f.read(4)==b'%PDF'
    zipped=tmp_path/'IDO_Analisis_Completo.zip'
    assert zipfile.is_zipfile(zipped)
    with zipfile.ZipFile(zipped) as f:
        names=set(f.namelist())
        assert {'05_matriz_covarianza_anual.csv','Informe_IDO.pdf','region_factible.png','analisis_completo.json'} <= names
