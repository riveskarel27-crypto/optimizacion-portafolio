from unittest.mock import patch
from fastapi.testclient import TestClient
from app.main import app
from tests.test_engine import synthetic_prices


def test_full_http_analysis_and_download():
    client=TestClient(app)
    assert client.get('/').status_code==200
    assert client.get('/api/health').json()['status']=='ok'
    with patch('app.main.load_prices',return_value=(synthetic_prices(65), [])):
        resp=client.post('/api/analyze',json={'tickers':['DUK','LQD','KIMBERA.MX','AC.MX'],
                                              'profile':'moderado','strategy':'long','risk_free_rate':4.0})
    assert resp.status_code==200, resp.text
    payload=resp.json()
    assert len(payload['portfolios'])==4
    assert payload['weights']['Perfil recomendado']
    assert payload['config']['n_observations']==65
    uri=payload['run_id']
    pdf=client.get(f'/api/download/{uri}/pdf')
    assert pdf.status_code==200 and pdf.content[:4]==b'%PDF'
    zipped=client.get(f'/api/download/{uri}/zip')
    assert zipped.status_code==200 and zipped.content[:2]==b'PK'
    assert client.get(f'/api/download/{uri}/region').status_code==200
    assert client.get('/api/download/../zip').status_code!=200
    assert client.get(f'/api/download/{uri}/wrong').status_code==404


def test_http_bad_request():
    c=TestClient(app)
    res=c.post('/api/analyze',json={'tickers':['INVALID TICKER','SPY'],'profile':'moderado','strategy':'long'})
    assert res.status_code==422
