"""Testing helpers for IDO."""
