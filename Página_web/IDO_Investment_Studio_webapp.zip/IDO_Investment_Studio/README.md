# IDO · Investment Studio

Plataforma web corporativa para análisis cuantitativo y optimización de portafolios long-only. Integra los tres códigos originales en un motor de datos histórico de Yahoo Finance (`yfinance`), estadística descriptiva, Shapiro-Wilk, optimización SLSQP, región factible, frontera eficiente y generación de informes descargables.

## Ejecutar

Necesitas **Python 3.11 o superior** e internet para consultar Yahoo Finance. Abre la carpeta raíz en la terminal:

**Windows**: ejecuta `iniciar_windows.bat` o escribe:

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

**macOS/Linux**:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

Abre **http://127.0.0.1:8000** en el navegador. Interfaz API: http://127.0.0.1:8000/api/docs.

## Qué calcula

1. Valida de 2 a 12 tickers Yahoo (ej. `SPY`, `LQD`, `DUK`, `AC.MX`, `KIMBERA.MX`). Descarga por separado el campo `Close` con `auto_adjust=True` y sincroniza las fechas. `end` de yfinance es exclusivo; el sistema lo ajusta para **incluir la fecha final** indicada en el formulario.
2. Selecciona periodo automáticamente o personalizado (ver limitaciones de Yahoo). Las recomendaciones de ventana son decisiones metodológicas orientativas, no garantías estadísticas.
3. Obtiene rendimientos simples, media, volatilidad, sesgo, curtosis de Pearson, Shapiro-Wilk, covarianzas, correlaciones y datos anualizados. `f = 252` en barras diarias, `252 × 6.5` por hora, `252 × 78` para 5 minutos y `252 × 390` para un minuto. Estos factores suponen un horario bursátil estadounidense regular: **son aproximaciones** y pueden ser inadecuados para activos mexicanos o barras faltantes.
4. Optimiza mínimo riesgo, máximo Sharpe, cartera equiponderada y cartera guiada por perfil con `scipy.optimize.minimize(method="SLSQP")`, 0 ≤ w_i ≤ 1, sum w_i=1. Se verifican la convergencia y las restricciones.
5. Construye región factible: bordes izquierdo (mínimo riesgo por retorno) y derecho (máximo de una función cuadrática convexa en los vértices de la sección del simplex). Incluye frontera eficiente, activos, modelos y una **CAL hipotética sólo si Sharpe es positivo**.
6. Ordena los activos evaluados mediante un **score relativo transparente** (volatilidad, máximo drawdown, ratio Sharpe, momentum), cuyo énfasis depende del perfil y del trading. No es una señal de entrada/salida ni asesoramiento de inversión.
7. Descarga **Informe_IDO.pdf** (texto, tablas, fórmulas renderizadas y gráficas) y **IDO_Analisis_Completo.zip** con los archivos anteriores, historial de precios, retornos, todas las matrices, tabla de portafolios, pesos, ranking, la malla de frontera y JSON.

### Perfiles y regla para la cartera sugerida

`Conservador` usa el portafolio de mínima varianza. `Patrimonial`, `Moderado`, `Integral` y `Profesional` fijan rendimientos objetivo respectivamente al 20%, 45%, 65% y 85% del recorrido entre el rendimiento GMVP y el máximo rendimiento medio de los instrumentos. Para cada objetivo se calcula la cartera de menor volatilidad. **Estas fracciones se eligieron para ilustrar perfiles, no sustituyen una evaluación de tolerancia al riesgo, pérdida máxima soportable, situación financiera ni criterios regulados de idoneidad.**

### Límites, supuestos y recomendaciones de operación

- Flash: 1 minuto y ventana automática de 5 días; day trading: 5 minutos, 28 días; swing: 1 hora, 55 días. Yahoo limita la profundidad intradía; algunos tickers no tienen este histórico. Position: cierres diarios, 18 meses; largo plazo: cierres diarios, 36 meses. El intradía puede fallar por calendarios y horarios de bolsas diferentes.
- El modelo trabaja con **rendimientos de precios en las monedas de cotización**. Si mezclas tickers mexicanos y estadounidenses, el análisis mostrará una advertencia: **no convierte monedas ni cubre riesgo cambiario**. Para uso con dinero real se deben convertir precios a una moneda base antes de estimar el portafolio.
- No incluye comisiones, spreads, impuestos, rotación, impuestos por dividendos, tamaños de lotes, profundidad del libro, restricciones regulatorias ni calidad de ejecución. No sirve para evaluar beneficios netos de trading flash.
- Los datos históricos son estimaciones muestrales, NO rendimientos futuros garantizados. La normalidad no es un requisito de la optimización media-varianza, pero debe examinarse el riesgo de cola. La CAL supone financiación a la tasa `r_f`, lo que no es necesariamente posible.
- No se usan precios/matrices fijas ni se ejecuta `pip install` desde la app. **No se borra ninguna base de datos MySQL** y no se guarda contraseña de acceso. Los resultados generados permanecen temporalmente en `runs/` y se limpian al volver a analizar, cuando tienen más de 24 horas.

## Pruebas sin red

```bash
python -m pytest -q
```

Se genera un histórico sintético fijo para revisar: sincronización, escala, objetivos, región factible, restricciones SLSQP, creación de reportes, ZIP y acceso a rutas. Para analizar activos reales debes ejecutar la aplicación con conexión a internet.

## Estructura

```text
app/engine.py       descarga, saneamiento, estadística, optimización y ranking
app/reporting.py    gráficas, CSV, JSON, PDF y ZIP
app/main.py         endpoints, validación y archivos temporales
static/index.html   interfaz web
static/styles.css   diseño empresarial responsive
static/app.js       interacción, dashboard y visualización
tests/              pruebas reproducibles
```

**Despliegue comercial:** antes de publicar en internet incorpora autenticación y aislamiento por usuario, términos de uso/licencias del proveedor, cuotas de consultas, caché, monitoreo, expiración de documentos, mecanismos de privacidad y revisión normativa para recomendaciones personalizadas. La versión suministrada está pensada para **uso local o una demostración controlada**.

Las fórmulas del panel se distribuyen como **SVG vectoriales ya renderizados** (`static/formulas/`), por lo que se ven tipográficamente incluso cuando falla la descarga de bibliotecas matemáticas externas.
