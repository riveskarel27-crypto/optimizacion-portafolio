#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt
printf 'Abre http://127.0.0.1:8000 en tu navegador.\n'
python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8000
